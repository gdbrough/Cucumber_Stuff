package com.training;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.service.SampleService;
import com.training.service.SampleServiceImpl;

@Configuration
public class AppConfig {
	@Bean
	public SampleService getSampleService() {
		return new SampleServiceImpl();
	}
}
