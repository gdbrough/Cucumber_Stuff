package model;

import java.io.Serializable;

public abstract class Sound implements Audible, Serializable {
	
	private static final long serialVersionUID = 1L;
	int volume;
	private String runtimeType;
	
	public Sound() {
		this.runtimeType = getClass().getSimpleName();
	}
	
	public int getVolume() {
		return volume;
	}
	
	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	public String getRuntimeType() {
		return runtimeType;
	}
	
	public void setRuntimeType(String runtimeType) {
		this.runtimeType = runtimeType;
	}

	@Override
	public String toString() {
		return "Sound [volume=" + volume + ", runtimeType=" + runtimeType + "]";
	}
}
