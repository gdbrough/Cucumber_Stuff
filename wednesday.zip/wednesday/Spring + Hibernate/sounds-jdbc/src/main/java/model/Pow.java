package model;

@SuppressWarnings("serial")
public class Pow extends Sound {
	
	public Pow(int volume) {
		this.volume = volume;
	}

	@Override
	public void makeNoise() {
		for(int i = 0; i < volume; i++) {
			System.out.println("Pow");
		}
	}
}