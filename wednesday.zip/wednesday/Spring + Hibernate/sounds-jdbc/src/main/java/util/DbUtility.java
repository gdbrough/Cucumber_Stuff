package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import model.Sound;

public class DbUtility implements Utility {

	// Oracle
	 private static final String DB_DRIVER =
	 "oracle.jdbc.driver.OracleDriver";
	 private static final String DB_CONNECTION =
	 "jdbc:oracle:thin:@localhost:1521:XE";
	 private static final String DB_USER = "lab";
	 private static final String DB_PASSWORD = "holland";

	// MySQL
//	private static final String DB_DRIVER = "com.mysql.jdbc.Driver";
//	private static final String DB_CONNECTION = "jdbc:mysql://localhost/jdbc?createDatabaseIfNotExist=true";
//	private static final String DB_USER = "root";
//	private static final String DB_PASSWORD = "letmein1";

	@Override
	public boolean save(Sound sound) {
		boolean allOk = false;
		Connection dbConnection = null;
		PreparedStatement preparedStatement = null;
		String insertTableSQL = "insert into sound (volume, type) values (?, ?)";
		try {
			dbConnection = getDBConnection();
			preparedStatement = dbConnection.prepareStatement(insertTableSQL);
			preparedStatement.setInt(1, sound.getVolume());
			preparedStatement.setString(2, sound.getRuntimeType());
			preparedStatement.executeUpdate();
			allOk = true;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return allOk;
	}

	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName(DB_DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		try {
			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER,
					DB_PASSWORD);
			return dbConnection;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return dbConnection;
	}

	@Override
	public boolean deleteAllSounds() {
		Connection dbConnection = null;
		boolean deleted = false;
		try {
			dbConnection = getDBConnection();
			String query = "delete from sound where 1=1";
			Statement statement = dbConnection.createStatement();
			deleted = statement.execute(query);
			dbConnection.close();
		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return deleted;
	}
}
