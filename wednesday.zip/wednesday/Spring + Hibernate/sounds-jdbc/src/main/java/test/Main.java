package test;

import util.DbUtility;
import util.FileUtility;
import util.Utility;
import model.Boom;
import model.Pow;
import model.Sound;

public class Main {
	
	public static void save(Sound sound) {
		Utility fileUtility = new FileUtility();
		Utility dbUtility = new DbUtility();
		fileUtility.save(sound);
		dbUtility.save(sound);
	}

	public static void main(String[] args) {
		Sound boom = new Boom(2);
		Sound pow = new Pow(4);
		save(boom);
		save(pow);
	}
}