-----------
-- MySQL --
-----------

CREATE TABLE `Person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `country` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
commit;

------------
-- Oracle -- 
------------

create sequence hibseq
start with 1
maxvalue 999999999999999999999999999
minvalue 1
nocycle
cache 20
noorder;

create table person (
	id number(11) not null,
	name varchar2(20) not null,
	country varchar2(20) not null,
	primary key (id)
);