package com.training;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.training.dao.PersonDAO;
import com.training.model.Person;

import static org.mockito.Mockito.*;

@SuppressWarnings("unused")
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("applicationContext-hib4-test.xml")
public class HibTests {
    
    @Autowired
    PersonDAO personDao;
    
	@Mock
	private Person mockPerson;
	
	@Mock
	private PersonDAO mockPersonDao;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testThatNameIsGregForNewPerson() {
		Person person = new Person();
		person.setName("Greg");
		person.setCountry("UK");
		personDao.save(person);
		List<Person> list = personDao.list();
		assertTrue(list.get(0).getName().equals("Greg"));
	}
	
	@Test
	public void testMockPerson() {
		when(mockPerson.getName()).thenReturn("Terry");
		String nameResult = mockPerson.getName();
		assertEquals(nameResult, "Terry");
	}
	
	@Test
	public void testMockPersonDao() {
		Person p1 = new Person();
		p1.setId(1);
		p1.setCountry("UK");
		p1.setName("Curtis");
		List<Person> list = new ArrayList<Person>();
		list.add(p1);
		when(mockPersonDao.list()).thenReturn(list);
		assertEquals(mockPersonDao.list(), list);
	}
}