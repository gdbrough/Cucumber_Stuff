package com.training;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.dao.PersonDAO;
import com.training.model.Person;

public class Main {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext-hib4.xml");

		PersonDAO personDAO = context.getBean(PersonDAO.class);

		Person person = new Person();
		person.setName("Greg");
		person.setCountry("UK");

		personDAO.save(person);

		System.out.println("Person::" + person);

		List<Person> list = personDAO.list();

		for (Person p : list) {
			System.out.println("Person List::" + p);
		}

		context.close();

	}

}
