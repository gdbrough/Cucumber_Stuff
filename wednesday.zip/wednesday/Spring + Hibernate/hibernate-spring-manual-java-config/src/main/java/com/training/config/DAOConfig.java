package com.training.config;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.springframework.context.annotation.Bean;

import com.training.dao.PersonDAO;
import com.training.dao.PersonDAOImpl;
import com.training.model.Person;

@org.springframework.context.annotation.Configuration
public class DAOConfig {
	
	@Bean(name="sessionFactoryBean")
	public SessionFactory SessionFactoryBean() {
		
		Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        configuration.addAnnotatedClass(Person.class);
        
        StandardServiceRegistryBuilder ssrb = new StandardServiceRegistryBuilder();
        ssrb.applySettings(configuration.getProperties());
        
        SessionFactory sessionFactory = configuration.buildSessionFactory(ssrb.build());
		
		return sessionFactory;
	}
	
	@Bean(name="personDAOBean")
	public PersonDAO PersonDAOBean()
	{
		PersonDAOImpl personDAOImpl = new PersonDAOImpl();
		personDAOImpl.setSessionFactory((SessionFactory)SessionFactoryBean());
		return personDAOImpl;
	}
}
