package com.training.challenge;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.DAOConfig;
import com.training.dao.PersonDAO;
import com.training.model.Person;

public class Main {

	public static void main(String[] args) {
		try(AnnotationConfigApplicationContext  context = 
				new AnnotationConfigApplicationContext(
				DAOConfig.class
				))
		{
			PersonDAO personDAO = (PersonDAO)context.getBean("personDAOBean");

			Person person = new Person();
			person.setName("Greg");
			person.setCountry("UK");

			personDAO.save(person);

			System.out.println("Person::" + person);

			List<Person> list = personDAO.list();

			for (Person p : list) {
				System.out.println("Person List::" + p);
			}

			context.close();	
		}
	}

}
