package model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
// Change to TABLE_PER_CLASS to store sounds in their own tables.
public abstract class Sound implements Audible, Serializable {
	
	private static final long serialVersionUID = 1L;
	protected int volume;
	private String runtimeType;
	private int id;
	
	public Sound() {
		this.runtimeType = getClass().getSimpleName();
	}
	
	public Sound(int id) {
		this.runtimeType = getClass().getSimpleName();
		this.id = id;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public int getVolume() {
		return volume;
	}
	
	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	public String getRuntimeType() {
		return runtimeType;
	}
	
	public void setRuntimeType(String runtimeType) {
		this.runtimeType = runtimeType;
	}

	@Override
	public String toString() {
		return "Sound [volume=" + volume + ", runtimeType=" + runtimeType + "]";
	}
}
