package test;

import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

import util.DbUtility;
import util.FileUtility;
import util.Utility;
import model.Boom;
import model.Pow;
import model.Sound;

public class Main {
	
	static Configuration configuration;
	
	public static void save(Sound sound) {
		Utility fileUtility = new FileUtility();
		Utility dbUtility = new DbUtility();
		fileUtility.save(sound);
		dbUtility.save(sound);
	}
	
	// Recreate schema.
	public static void schemaExport() {
		configuration = new Configuration();
		configuration.addAnnotatedClass(Sound.class);
		configuration.addAnnotatedClass(Boom.class);
		configuration.addAnnotatedClass(Pow.class);
		configuration.configure("hibernate.cfg.xml");
		new SchemaExport(configuration).create(true, true);
	}

	public static void main(String[] args) {

		schemaExport();
		Sound boom = new Boom(2);
		Sound pow = new Pow(4);
		save(boom);
		save(pow);
	}
}