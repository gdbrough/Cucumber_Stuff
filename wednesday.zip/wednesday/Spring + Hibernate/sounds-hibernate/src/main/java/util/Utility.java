package util;

import model.Sound;

public interface Utility {

	public abstract boolean save(Sound sound);
}
