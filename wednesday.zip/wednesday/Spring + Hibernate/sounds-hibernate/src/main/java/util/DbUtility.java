package util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import model.Boom;
import model.Pow;
import model.Sound;

public class DbUtility implements Utility {
	
	static SessionFactory sessionFactory;
	
	static {
		Configuration configuration = new Configuration();
		configuration.addAnnotatedClass(Sound.class);
		configuration.addAnnotatedClass(Boom.class);
		configuration.addAnnotatedClass(Pow.class);
		configuration.configure("hibernate.cfg.xml");

		StandardServiceRegistryBuilder ssrb = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties());
		sessionFactory = configuration.buildSessionFactory(ssrb
				.build());
	}
	
	@Override
	public boolean save(Sound sound) {
		boolean allOk = false;
		Session session = getSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();

			session.save(sound);
			
			// Quick check.
			Sound s = (Sound) session.get(Sound.class, sound.getId());
			System.out.println("Sound retrieved is a: " + s.getRuntimeType() + ", at volume: " + s.getVolume());

			tx.commit();
			tx = null;
			allOk = true;
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			// Should probably expose this a layer above.
			sessionFactory.close();
		}
		return allOk;
	}
	
	private static Session getSession() {
		Session session = sessionFactory.openSession();
		return session;
	}
}