package util;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import model.Sound;

public class FileUtility implements Utility {

	@Override
	public boolean save(Sound sound) {
		boolean allOk = false;
		try{
 
			FileOutputStream fout = new FileOutputStream("sound.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fout);   
			oos.writeObject(sound);
			oos.close();
			allOk = true;
 
		} catch(Exception ex){
		   ex.printStackTrace();
	    }
		return allOk;
	}
}