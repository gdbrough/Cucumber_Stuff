package test;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;




import util.Utility;
import model.Boom;
import model.Pow;
import model.Sound;

public class Main {
	
	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		Utility soundHibUtil = (Utility) context.getBean("soundHibUtility");
		Sound boom = new Boom(2);
		Sound pow = new Pow(4);
		
		// Hib save/list.
		soundHibUtil.save(boom);
		soundHibUtil.save(pow);
		List<Sound> list = soundHibUtil.list();
		for (Sound s : list) {
			System.out.println("Sounds List: " + s);
		}
		
		// File save/list not implemented.
		
		context.close();
	}
}