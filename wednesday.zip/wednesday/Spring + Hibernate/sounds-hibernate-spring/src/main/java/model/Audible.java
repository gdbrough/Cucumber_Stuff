package model;

public interface Audible {

	public abstract void makeNoise();
}
