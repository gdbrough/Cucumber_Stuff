package model;

import javax.persistence.Entity;

@SuppressWarnings("serial")
@Entity
public class Pow extends Sound {
	
	public Pow() {
		super();
	}
	
	public Pow(int volume) {
		this.volume = volume;
	}

	@Override
	public void makeNoise() {
		for(int i = 0; i < volume; i++) {
			System.out.println("Pow");
		}
	}
}