package util;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import model.Sound;

public class DbUtility implements Utility {
	
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void save(Sound s) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.persist(s);
		tx.commit();
		session.close();
	}

	@SuppressWarnings("unchecked")
	public List<Sound> list() {
		Session session = this.sessionFactory.openSession();
		List<Sound> soundList = session.createQuery("from Sound").list();
		session.close();
		return soundList;
	}
}