package util;

import java.util.List;

import model.Sound;

public class FileUtility implements Utility {

	@Override
	public void save(Sound sound) {}

	@Override
	public List<Sound> list() { 
		return null;
	}
}