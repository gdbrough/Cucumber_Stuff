package util;

import java.util.List;

import model.Sound;

public interface Utility {

	public abstract void save(Sound s);
	public List<Sound> list();
}
