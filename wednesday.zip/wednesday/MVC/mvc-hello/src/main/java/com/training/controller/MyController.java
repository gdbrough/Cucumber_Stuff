package com.training.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/welcome")
	public ModelAndView helloWorld() {
		String message = "<h1>Hello World, Spring4 MVC Hello</h1>This message is from Greg.";
		return new ModelAndView("welcome", "message", message);
	}
	
	@RequestMapping("/more")
	public ModelAndView more() {
		String message = "<h1>More Here</h1>";
		return new ModelAndView("more", "message", message);
	}
}