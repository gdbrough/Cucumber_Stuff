package datasource;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

public class UserDao {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
//	public List<User> findAllUsers() {
//		String sql = "select * from users";
//		 
//		List<User> users = new ArrayList<User>();
//	 
//		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
//		for (Map<String, Object> row : rows) {
//			User user = new User();
//			user.setId((BigDecimal)row.get("ID"));
//			user.setUserName((String)(row.get("USERNAME")));
//			user.setPassword((String)(row.get("PASSWORD")));
//			user.setEnabled((String)(row.get("ENABLED")));
//			users.add(user);
//		}
//		return users;
//	}

	public String deleteUser(int id) {
		String ret = "";
		String delQuery = "delete from users where id = ?";
		int count = jdbcTemplate.update(delQuery, new Object[] { id });
		if (count != 0) {
			ret = "User deleted successfully.";
		} else {
			ret = "Couldn't delete user with given id as it doesn't exist";
		}
		return ret;
	}

//	public int insertUser(User user) {
//		String inserQuery = "insert into users (username, password, enabled , id) values (?, ?, ?, ?)";
//		Object[] params = new Object[] { user.getUserName(),
//				user.getPassword(), user.isEnabled(), user.getId() };
//		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.BIT,
//				Types.INTEGER };
//		return jdbcTemplate.update(inserQuery, params, types);
//	}
}
