package datasource;

import java.math.BigDecimal;

public class User {

	// Code here.	
}