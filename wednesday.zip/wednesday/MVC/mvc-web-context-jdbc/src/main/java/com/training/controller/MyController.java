package com.training.controller;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import datasource.User;
import datasource.UserDao;

@Controller
public class MyController {
	
	@Autowired
	ServletContext context;
	static int idCounter;
	 
	@RequestMapping("/welcome")
	public ModelAndView helloWorld() {
 
		String message = "<h1>Hello World, Spring4 MVC WebContext JDBC</h1>This message is from Greg.";
		
		// Use bean from context.
		WebApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(context);
		UserDao userDao = (UserDao) ctx.getBean("userDao");
		
		// New part.
		User u = new User();
		u.setId(new BigDecimal(++idCounter));
		u.setUserName("GC");
		u.setPassword("pass");
		u.setEnabled("true");
		userDao.insertUser(u);
		
		
		List<User> users = userDao.findAllUsers();
		for(User user : users) {
			message += ("<h3>" + user + "</h3>");
		}
		return new ModelAndView("welcome", "message", message);
	}
}