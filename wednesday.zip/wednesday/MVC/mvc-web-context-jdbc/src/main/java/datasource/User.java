package datasource;

import java.math.BigDecimal;

public class User {

	private String userName;
	private String enabled;
	private BigDecimal id;
	private String password;
	
	public User() {
	}

	public User(BigDecimal id, String userName, String password, String enabled) {
		this.id = id;
		this.password = password;
		this.userName = userName;
		this.enabled = enabled;
	}

	public String getUserName() {
		return this.userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return this.password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

	public String isEnabled() {
		return this.enabled;
	}

	public void setEnabled(String string) {
		this.enabled = string;
	}

	public BigDecimal getId() {
		return this.id;
	}
	
	public void setId(BigDecimal bigDecimal) {
		this.id = bigDecimal;
	}

	@Override
	public String toString() {
		return "User [userName=" + userName + ", enabled=" + enabled + ", id="
				+ id + ", password=" + password + "]";
	}	
}