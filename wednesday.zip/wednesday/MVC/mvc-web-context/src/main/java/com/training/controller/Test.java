package com.training.controller;

public class Test {

	String name;
	
	public Test(String name) {
		this.name = name;
	}
}
