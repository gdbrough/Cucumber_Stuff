package com.training.controller;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@Autowired
	ServletContext context;
 
	@RequestMapping("/welcome")
	public ModelAndView helloWorld() {
 
		String message = "<h1>Hello World, Spring4 MVC WebContext JDBC</h1>This message is from: ";
		
		// Use bean from context.
		WebApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(context);
		Test test = (Test) ctx.getBean("test");
		message += test.name;
		return new ModelAndView("welcome", "message", message);
	}
}