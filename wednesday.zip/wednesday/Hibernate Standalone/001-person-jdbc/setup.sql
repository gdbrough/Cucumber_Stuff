create sequence person_id_seq
start with 1
maxvalue 999999999999999999999999999
minvalue 1
nocycle
cache 20
noorder;

create table person (
	id number(11) not null,
	name varchar2(20) not null,
	primary key (id)
);

