package com.training;

public class OracleConstants {

	public static final String URL = "jdbc:oracle:thin:lab/hholland@localhost:1521:XE";

	public static String GET_PERSON_ID = "select person_id_seq.nextval from dual";

	public static String CREATE_PERSON = "insert into person(id, name) values (?, ?)";

	public static String UPDATE_PERSON = "update person set name = ? where id = ?";

	public static String DELETE_PERSON = "delete from person where id = ?";

	public static String GET_PERSON = "select id, name from person where id = ?";

}