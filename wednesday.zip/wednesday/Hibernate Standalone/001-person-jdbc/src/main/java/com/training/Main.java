package com.training;

public class Main {

	public static void main(String[] args) {
		
//		createAndDeletePerson();
//		createAndUpdateAndDeletePerson();
		
		createAndDeletePersonOracle();
		createAndUpdateAndDeletePersonOracle();
	}
	
	private static void createAndUpdateAndDeletePersonOracle() {
		// Create.
		Person person = new Person();
		person.setName("Curtis");

		// Save.
		PersonService personService = new OraclePersonService();
		person = personService.createPerson(person);

		// Display.
		System.out.println("Original: " + person);

		// Update.
		person.setName("New Name");
		personService.updatePerson(person);

		// Display updated.
		System.out.println("Updated: " + person);

		// Delete.
		personService.deletePerson(person);
	}

	private static void createAndDeletePersonOracle() {
		// Create.
		Person person = new Person();
		person.setName("Curtis");

		// Save.
		PersonService personService = new OraclePersonService();
		person = personService.createPerson(person);

		// Display.
		System.out.println(person);

		// Delete.
		personService.deletePerson(person);
	}

	/*
	private static void createAndUpdateAndDeletePerson() {
		// Create.
		Person person = new Person();
		person.setName("Curtis");

		// Save.
		PersonService personService = new OraclePersonService();
		person = personService.createPerson(person);

		// Display.
		System.out.println("Original: " + person);
		
		// Update.
		person.setName("New Name");
		personService.updatePerson(person);
		
		// Display updated.
		System.out.println("Updated: " + person);
		
		// Delete.
		personService.deletePerson(person);		
	}
	*/

	/*
	@SuppressWarnings("unused")
	private static void createAndDeletePerson() {
		// Create.
		Person person = new Person();
		person.setName("Curtis");

		// Save.
		PersonService personService = new OraclePersonService();
		person = personService.createPerson(person);

		// Display.
		System.out.println(person);

		// Delete.
		personService.deletePerson(person);
	}
	*/
}
