package com.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySqlPersonService implements PersonService {

	@Override
	public Person createPerson(Person person) {
		Connection connection = null;
		PreparedStatement getPersonIdStatement = null;
		PreparedStatement createPersonStatement = null;
		ResultSet resultSet = null;
		int personId = 0;
		try {
			connection = getConnection();
//			getPersonIdStatement = connection
//					.prepareStatement(MySqlConstants.GET_PERSON_ID);
//			resultSet = getPersonIdStatement.executeQuery();
//			resultSet.next();
//			personId = resultSet.getInt(1);

			createPersonStatement = connection
					.prepareStatement(MySqlConstants.CREATE_PERSON);
			createPersonStatement.setInt(1, personId);
			createPersonStatement.setString(2, person.getName());
			createPersonStatement.execute();

			connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				throw new RuntimeException(e1);
			}
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			cleanupDatabaseResources(null, getPersonIdStatement, resultSet);
			cleanupDatabaseResources(connection, createPersonStatement, null);
		}
		return getPerson(personId);
	}

	@Override
	public void updatePerson(Person person) {
		
		Connection connection = null;
		PreparedStatement updatePersonStatement = null;
		try {
			connection = getConnection();
			updatePersonStatement = connection
					.prepareStatement(MySqlConstants.UPDATE_PERSON);
			updatePersonStatement.setString(1, person.getName());
			updatePersonStatement.setInt(2, person.getId());
			updatePersonStatement.execute();
			connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try{
				connection.rollback();
			}catch(SQLException e1){
				e.printStackTrace();
				throw new RuntimeException(e1);
			}
			throw new RuntimeException(e);
		} finally {
			cleanupDatabaseResources(connection, updatePersonStatement, null);
		}

	}

	@Override
	public Person getPerson(int personId) {
		Connection connection = null;
		PreparedStatement getPersonStatement = null;
		ResultSet resultSet = null;
		try {
			connection = getConnection();
			getPersonStatement = connection
					.prepareStatement(MySqlConstants.GET_PERSON);
			getPersonStatement.setInt(1, personId);
			resultSet = getPersonStatement.executeQuery();

			Person person = null;
			if (resultSet.next()) {
				person = new Person();
				person.setId(resultSet.getInt("ID"));
				person.setName(resultSet.getString("NAME"));
			}
			connection.commit();
			return person;

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				throw new RuntimeException(e1);
			}
			throw new RuntimeException(e);
		} finally {
			cleanupDatabaseResources(connection, getPersonStatement, resultSet);
		}
	}

	@Override
	public void deletePerson(Person person) {

		Connection connection = null;
		PreparedStatement deletePersonStatement = null;
		try {
			connection = getConnection();
			deletePersonStatement = connection
					.prepareStatement(MySqlConstants.DELETE_PERSON);
			deletePersonStatement.setInt(1, person.getId());
			deletePersonStatement.execute();
			connection.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				throw new RuntimeException(e1);
			}
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			cleanupDatabaseResources(connection, deletePersonStatement, null);
		}

	}

	protected Connection getConnection() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		Connection connection = DriverManager
				.getConnection(MySqlConstants.URL);
		connection.setAutoCommit(false);
		return connection;
	}

	protected void cleanupDatabaseResources(Connection connection,
			Statement statement, ResultSet resultSet) {
		try {
			if (resultSet != null) {
				resultSet.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}