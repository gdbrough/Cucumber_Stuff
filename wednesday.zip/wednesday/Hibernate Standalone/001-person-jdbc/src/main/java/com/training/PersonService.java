package com.training;

public interface PersonService {

	public Person createPerson(Person person);

	public void updatePerson(Person person);

	public Person getPerson(int personId);

	public void deletePerson(Person person);

}