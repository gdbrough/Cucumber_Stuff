package com.training;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

	public static void main(String [] args) {

	    Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		try {
			
			Person p1 = new Person();
			p1.setName("Greg Curtis");
			session.save(p1);
			
			Person p2 = new Person();
			p2.setName("Kevin Saunderson");
			session.save(p2);

			Person person = (Person) session.get(Person.class, p1.getId());
			System.out.println("First person retrieved = " + person.getName());
			person = (Person) session.get(Person.class, p2.getId());
			System.out.println("Second person retrieved = " + person.getName());

			transaction.commit();
			transaction = null;
		
		} catch (HibernateException e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		} finally {
			session.close();
			HibernateUtil.shutdown();
		}
	}
}