package com.training;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("hibjpa");
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();

		try {
			Person person = new Person();
			person.setName("Pibbles");
			em.persist(person);
			Person person2 = new Person();
			person2.setName("Bojangles");
			em.persist(person2);
			transaction.commit();
			transaction = null;
			System.out.println("Person successfully persisted.");
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		} finally {
			em.close();
			entityManagerFactory.close();
		}
	}
}