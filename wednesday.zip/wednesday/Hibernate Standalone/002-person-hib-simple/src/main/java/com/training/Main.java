package com.training;

import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Main {
	
	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			try {
				registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
				MetadataSources sources = new MetadataSources(registry);
				Metadata metadata = sources.getMetadataBuilder().build();
				sessionFactory = metadata.getSessionFactoryBuilder().build();
			} catch (Exception e) {
				e.printStackTrace();
				if (registry != null) {
					StandardServiceRegistryBuilder.destroy(registry);
				}
			}
		}
		return sessionFactory;
	}
	
	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}

	public static void main(String[] args) {

		Session session = getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();;
		try {
			// Create a Person object and save it.
			Person p1 = new Person();
			p1.setName("Greg Curtis");
			session.save(p1);

			Person p2 = new Person();
			p2.setName("Kevin Saunderson");
			session.save(p2);
			
			p2.setName("Changed");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			Person person = (Person) session.get(Person.class, p1.getId());
			System.out.println("First person retrieved = " + person.getName());
			person = (Person) session.get(Person.class, p2.getId());
			System.out.println("Second person retrieved = " + person.getName());

			tx.commit();
			tx = null;
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
			shutdown();
		}
	}
}