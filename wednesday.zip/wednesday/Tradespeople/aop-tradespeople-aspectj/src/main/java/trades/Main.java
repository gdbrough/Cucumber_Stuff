package trades;

import org.springframework.context.*;
import org.springframework.context.support.*;

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"/applicationContext.xml");
		//TradesPerson builder = (TradesPerson) context.getBean("builder");
		//printInfo(builder);
		//TradesPerson electrician = (TradesPerson) context.getBean("electrician");
		//printInfo(electrician);
		//TradesPerson plumber = (TradesPerson) context.getBean("plumber");
		//printInfo(plumber);
		
		Project project = (Project) context.getBean("project");
		System.out.println("21 day project cost: " + (project.getDailyCost() * 23));
		
		// 23 days with 2 x B, 1 x P, 1 x E = �32807.200000000004
		// 23 days with 1 x AB, 1 x P, 1 x E = �25805.54
	}

	@SuppressWarnings("unused")
	private static void printInfo(TradesPerson t) {
		System.out.printf("%s with rate of %,.2f%n", t.getClass()
				.getSimpleName(), t.getRate());
	}
}