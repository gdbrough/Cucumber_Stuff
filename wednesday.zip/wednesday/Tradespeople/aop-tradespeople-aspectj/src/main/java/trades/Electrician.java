package trades;

public class Electrician implements TradesPerson {

	double rate;

	public Electrician() {
	}

	public Electrician(double rate) {
		setRate(rate);
	}
	
	public double getRate() {
		return rate;
	}
	
	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Electrician [rate=" + rate + "]";
	}
}