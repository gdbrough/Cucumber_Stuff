package trades;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class Project {

	List<TradesPerson> tradesPeople;
	String type;
	
	//@Resource(name="workers")
	@Autowired
	public void setTradesPeople(List<TradesPerson> tradesPeople) {
		this.tradesPeople = tradesPeople;
	}	
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public double getDailyCost() {
		double dailyCost = 0;
		for(TradesPerson t : tradesPeople) {
			dailyCost += t.getRate();
		}
		return dailyCost;
	}

	@Override
	public String toString() {
		return "Project [tradesmen=" + tradesPeople + ", type=" + type + "]";
	}
}