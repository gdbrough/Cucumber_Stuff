package trades;

public interface TradesPerson {
  public double getRate();
}
