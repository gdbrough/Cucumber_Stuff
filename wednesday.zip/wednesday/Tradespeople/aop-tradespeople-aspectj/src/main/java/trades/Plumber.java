package trades;

public class Plumber implements TradesPerson {

	double rate;

	public Plumber() {
	}

	public Plumber(double rate) {
		setRate(rate);
	}
	
	public double getRate() {
		return rate;
	}
	
	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Plumber [rate=" + rate + "]";
	}
}