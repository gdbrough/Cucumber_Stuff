package trades;

public class Builder implements TradesPerson {

	double rate;

	public Builder() {
	}

	public Builder(double rate) {
		setRate(rate);
	}
	
	public double getRate() {
		return rate;
	}
	
	public void setRate(double rate) {
		this.rate = rate;
	}

	@Override
	public String toString() {
		return "Builder [rate=" + rate + "]";
	}
}
