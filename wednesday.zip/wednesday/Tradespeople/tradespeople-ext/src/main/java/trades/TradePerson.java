package trades;

public abstract class TradePerson {
	
	enum TradeType{
		Builder,Electrician,Plumber
	}

	private TradeType type;

	public TradePerson(TradeType type) {
		this.type = type;
	}

	public TradeType getType() {
		return type;
	}

	public void setType(TradeType type) {
		this.type = type;
	}

	public abstract double getRate();


	
	

	

}
