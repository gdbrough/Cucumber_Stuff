package trades;

import org.springframework.beans.factory.annotation.Value;

public class Plumber extends TradePerson {

	@Value("${plumber.rate}")
	private double rate;

	public Plumber() {
		super(TradeType.Plumber);
	}

	@Override
	public double getRate() {
		return rate;
	}

	@Override
	public String toString() {
		return "Plumber [rate=" + rate + "]";
	}
}
