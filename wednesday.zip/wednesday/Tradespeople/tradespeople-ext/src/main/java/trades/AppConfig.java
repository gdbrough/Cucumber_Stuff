package trades;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import trades.TradePerson.TradeType;

@Configuration
@PropertySource("classpath:app.properties")
public class AppConfig {
	
	@Value("${${template}.tradesPersonList}")
	private String[] tradesPersonList;

	@Bean
	@Scope("prototype")
	public TradePerson tradeperson(TradeType type){
		switch(type){
		case Builder:
			return new Builder();
		case Electrician:
			return new Electrician();
		case Plumber:
			return new Plumber();
	
		}
		return null;
	}


	@Bean 
	public Project project(){
		Project project = new Project();
		for(String person:tradesPersonList){
			project.addTrade(tradeperson(TradeType.valueOf(person)));
		}
		return project;
	}
	

}
