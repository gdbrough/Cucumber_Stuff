package trades;

import org.springframework.beans.factory.annotation.Value;

public class Electrician extends TradePerson {

	@Value("${electrician.rate}")
	private double rate;

	public Electrician() {
		super(TradeType.Electrician);
	}

	@Override
	public double getRate() {
		return rate;
	}

	@Override
	public String toString() {
		return "Electrician [rate=" + rate + "]";
	}

}
