package trades;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;

public class Project {
	
	@Value("${${template}.duration}")
	private int duration;
	
	private List<TradePerson> tradeFolk = new ArrayList<>();

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void addTrade(TradePerson tradeperson) {
		tradeFolk.add(tradeperson);
	}

	public double getCost() {
		return tradeFolk.stream().mapToDouble(TradePerson::getRate).sum() * duration;
	}

	@Override
	public String toString() {
		return "Project [duration=" + duration + ", tradeFolk=" + tradeFolk + "]";
	}
	
	
}
