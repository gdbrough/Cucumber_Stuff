package trades;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
	
	public static void main(String[] args) {
		try(AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class)){
			Project project = context.getBean(Project.class);
			System.out.println(project);
			System.out.println(project.getCost());
		}
	}

}
