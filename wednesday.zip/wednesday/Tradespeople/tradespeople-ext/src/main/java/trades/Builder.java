package trades;

import org.springframework.beans.factory.annotation.Value;

public class Builder extends TradePerson {

	@Value("${builder.rate}")
	private double rate;

	public Builder() {
		super(TradeType.Builder);
	}

	@Override
	public double getRate() {
		return rate;
	}

	@Override
	public String toString() {
		return "Builder [rate=" + rate + "]";
	}
	
}
