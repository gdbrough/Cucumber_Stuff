package trades;

import org.springframework.context.support.*;

public class Main {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"/applicationContext.xml")) {
//		TradesPerson builder = (TradesPerson) context.getBean("builder");
//		printInfo(builder);
//		TradesPerson electrician = (TradesPerson) context.getBean("electrician");
//		printInfo(electrician);
//		TradesPerson plumber = (TradesPerson) context.getBean("plumber");
//		printInfo(plumber);

		Project projProxy = (Project) context.getBean("projectProxy");
		//Project project = (Project) context.getBean("project");
		System.out.println("23 day project cost: " + (projProxy.getDailyCost() * 23));
		}
	}

	@SuppressWarnings("unused")
	private static void printInfo(TradesPerson t) {
		System.out.printf("%s with area of %,.2f%n", t.getClass()
				.getSimpleName(), t.getRate());
	}
}