package config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;

import interfaces.IProject;
import interfaces.ITradesPerson;
import models.Project;

@Configuration
@PropertySource("classpath:project.properties")
public class ProjectConfig {
	
	@Autowired
	public ITradesPerson builderBean;	
	@Autowired
	public ITradesPerson electricianBean;
	@Autowired
	public ITradesPerson plumberBean;
	
	@Autowired
	private Environment env;
	
	@Bean(name="projectBean")
	@Scope("prototype")
	public IProject Project(){
		
		// Get project configuration
		int projectDuration = Integer.parseInt(env.getProperty("project.duration"));
		int builderCount = Integer.parseInt(env.getProperty("project.builder.count"));
		int electricianCount= Integer.parseInt(env.getProperty("project.electrician.count"));
		int plumberCount= Integer.parseInt(env.getProperty("project.plumber.count"));
		
		Project project = new Project();
		for (int i = 0; i < builderCount; i++) {
			project.addTradesPerson(builderBean);
		}
		for (int i = 0; i < electricianCount; i++) {
			project.addTradesPerson(electricianBean);
		}
		for (int i = 0; i < plumberCount; i++) {
			project.addTradesPerson(plumberBean);
		}
		project.setDuration(projectDuration);
		
		return project;
	}
}
