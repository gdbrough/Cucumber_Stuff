package config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import interfaces.ITradesPerson;
import models.TradePerson;

@Configuration
@PropertySource("classpath:rates.properties")
public class TradesPeopleConfig {
	
	@Value("${builder.rate}")
	private double builderRate;
	@Value("${electrician.rate}")
	private double electricianRate;
	@Value("${plumber.rate}")
	private double plumberRate;
	
	@Bean(name="builderBean")
	@Scope("prototype")
	public ITradesPerson Builder(){
		return new TradePerson(builderRate, "builder");
	}
	
	@Bean(name="electricianBean")
	@Scope("prototype")
	public ITradesPerson Electrician(){
		return new TradePerson(electricianRate, "electrician");
	}
	
	@Bean(name="plumberBean")
	@Scope("prototype")
	public ITradesPerson Plumber(){
		return new TradePerson(plumberRate, "plumber");
	}
	
}
