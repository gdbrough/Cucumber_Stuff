package models;

import interfaces.ITradesPerson;

public class TradePerson implements ITradesPerson {

	private String type;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public TradePerson(double rate, String type){
		this.rate = rate;
		this.type = type;
	}
	
	private double rate;

	@Override
	public double getRate() {
		return rate;
	}
	
	@Override
	public String toString() {
		return "Tradesperson: Type "+type+", Rate "+rate;
	}
}
