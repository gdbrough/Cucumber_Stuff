package models;

import java.util.ArrayList;
import java.util.List;

import interfaces.IProject;
import interfaces.ITradesPerson;

public class Project implements IProject {
	
	private List<ITradesPerson> tradesPeople = new ArrayList<ITradesPerson>();
	private int duration;
	
	@Override
	public void addTradesPerson(ITradesPerson tradesPerson) {
		tradesPeople.add(tradesPerson);
	}

	@Override
	public double getEstimate() {
		double estimate = 0.0;
		for (ITradesPerson tradesPerson : tradesPeople) {
			System.out.println("Quoting: "+tradesPerson);
			estimate += tradesPerson.getRate();
		}
		return estimate * (double) duration;
	}

	@Override
	public void setDuration(int days) {
		this.duration = days;
	}
}
