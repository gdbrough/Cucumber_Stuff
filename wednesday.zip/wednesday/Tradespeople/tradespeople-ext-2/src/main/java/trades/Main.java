package trades;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.PropertySource;

import config.ProjectConfig;
import config.TradesPeopleConfig;
import interfaces.IProject;

@PropertySource("classpath:project.properties")
public class Main {

	public static void main(String[] args) {
			try(AnnotationConfigApplicationContext context 
					= new AnnotationConfigApplicationContext(ProjectConfig.class, TradesPeopleConfig.class))
		{
			IProject project = (IProject)context.getBean("projectBean");
			System.out.println("Project estimate: "+project.getEstimate());
		}
	}

}
