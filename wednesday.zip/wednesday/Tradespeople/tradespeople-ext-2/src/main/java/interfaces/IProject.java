package interfaces;

public interface IProject {
	void addTradesPerson(ITradesPerson tradesPerson);
	double getEstimate();
	void setDuration(int days);
}
