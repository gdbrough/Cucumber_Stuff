package interfaces;

public interface ITradesPerson {
	double getRate();
}
