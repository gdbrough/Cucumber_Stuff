package starter;

import java.text.MessageFormat;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;

public class Main {
	public static void main(String args[]) {

		try {
			SingleConnectionDataSource ds = new SingleConnectionDataSource();
			ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
			ds.setUrl(MessageFormat
					.format("jdbc:oracle:thin:lab/holland@localhost:1521",
							"XE"));
			ds.setUsername("lab");
			ds.setPassword("holland");

			JdbcTemplate jt = new JdbcTemplate(ds);
			jt.execute("create table employeestarter (id number, name varchar2(20))");
			jt.execute("insert into employeestarter (id, name) values (1, 'Alan')");
			jt.execute("insert into employeestarter (id, name) values (2, 'Bob')");
			jt.execute("insert into employeestarter (id, name) values (3, 'Claire')");
			jt.execute("insert into employeestarter (id, name) values (4, 'Dave')");
			jt.execute("insert into employeestarter (id, name) values (5, 'Ellen')");
			jt.execute("insert into employeestarter (id, name) values (6, 'Francis')");

			Object[] parameters = new Object[] { new Integer(2) };
			Object o = jt.queryForObject(
					"select name from employeestarter where id = ?",
					parameters, String.class);
			System.out.println((String) o);

			ds.destroy();
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}
}