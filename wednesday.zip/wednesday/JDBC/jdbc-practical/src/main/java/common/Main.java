package common;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.CustomerDAO;
import model.Customer;

public class Main {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml")) {
			/*
			 * Build an instance of the DAO.
			 * Create a new Customer and insert.
			 * Use the DAO's finder method to prove the insert.
			 * 
			 */
			
			CustomerDAO customerDAO = (CustomerDAO) context.getBean("customerDAO");
			Customer customer = new Customer(79, "Curtis", 36);
			customerDAO.insert(customer);
			
			Customer customer1 = customerDAO.findByCustomerId(79);
			System.out.println(customer1);
		}
	}
}