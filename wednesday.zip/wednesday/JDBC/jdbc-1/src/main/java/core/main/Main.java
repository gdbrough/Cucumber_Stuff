package core.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import core.Customer;
import core.CustomerQuery;

public class Main {

	public static void main(String[] args) {

		try(ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"/core/main/applicationContext.xml")) {
			CustomerQuery query = (CustomerQuery) context
					.getBean("customerQuery");

			Customer customer = query.getCustomerByName("Greg Curtis");

			System.out.println(customer);
		}
	}
}
