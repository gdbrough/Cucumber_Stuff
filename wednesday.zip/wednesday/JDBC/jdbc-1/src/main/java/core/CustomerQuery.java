package core;

public interface CustomerQuery {

	public Customer getCustomerByName(String name);
}