package core.util;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * DataSource implementation for an embedded Derby database instance.
 */
public class OracleDataSource extends DriverManagerDataSource {

	private static final Logger log = Logger.getLogger(OracleDataSource.class);

	/**
	 * Creates a new OracleDataSource instance.
	 * <p>
	 * Initializes the instance with a custom database name and optionally a
	 * list of setup scripts to be sourced from the class path and executed.
	 * 
	 * @param databaseName
	 *            required
	 * @param scriptPaths
	 *            optional
	 * @throws IllegalArgumentException
	 *             for parameter spec violations
	 */
	public OracleDataSource(final String databaseName, String... scriptPaths) {
		// prerequisites
		if (databaseName == null) {
			throw new IllegalArgumentException("Required: database name.");
		}

		// configure DataSource
		super.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		super.setUrl(MessageFormat.format(
				"jdbc:oracle:thin:springjpm/springjpm@localhost:1521",
				databaseName));

		// init tables and seed data
		if (scriptPaths != null) {
			for (String scriptPath : scriptPaths) {
				List<SqlCommand> commands = null;
				try {
					commands = SqlCommand.parseResourcePath(scriptPath);
				} catch (IOException e) {
					throw new IllegalStateException(
							"Error: I/O for SQL scripts." + " Failed to load: "
									+ scriptPath, e);
				}
				for (SqlCommand sqlCmd : commands) {
					try {
						sqlCmd.setIgnoreError(true).execute(this);
					} catch (SQLException e) {
						log.warn("Error: setup SQL. Failed to execute: "
								+ sqlCmd, e);
					}
				}
			}
		}

		// shutdown
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				String shutdownCmd = MessageFormat.format(
						"jdbc:derby:{0};shutdown=true", databaseName);
				try {
					DriverManager.getConnection(shutdownCmd);
					throw new IllegalStateException("Error: DB shutdown."
							+ " Failed to shutdown database using command: "
							+ shutdownCmd);
				} catch (SQLException e) {
					log.info("Oracle DB shutdown");
					// oddly, the driver throws a SQLException to verify
					// shutdown.
					// therefore, anticipate an error rather than normal
					// execution
				}
			}
		});
	}
}
