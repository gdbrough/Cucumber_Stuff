package core.standalone;

import core.Customer;
import core.CustomerQuery;
import core.SpringJdbcCustomerQuery;
import core.util.OracleDataSource;

//import core.util.EmbeddedDerbyDataSource;

public class Main {

	public static void main(String[] args) throws Exception {

		/*
		 * // Derby EmbeddedDerbyDataSource dataSource = new
		 * EmbeddedDerbyDataSource("target/ngcdb", "/setup.sql"); CustomerQuery
		 * query = new SpringJdbcCustomerQuery(dataSource); Customer customer =
		 * query.getCustomerByName("Java Joe"); System.out.println(customer);
		 */

		// Oracle
		OracleDataSource dataSource = new OracleDataSource("XE",
				"/setupOracle.sql");
		CustomerQuery query = new SpringJdbcCustomerQuery(dataSource);
		Customer customer = query.getCustomerByName("Greg Curtis");
		System.out.println(customer);

	}

}
