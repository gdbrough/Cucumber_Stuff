package core;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SingleColumnRowMapper;

public class SpringJdbcCustomerQuery implements CustomerQuery {

	private JdbcTemplate jdbc;

	public SpringJdbcCustomerQuery(DataSource dataSource) {
		this.jdbc = new JdbcTemplate(dataSource);
	}

	public Customer getCustomerByName(String customerName) {
		try {
			return this.jdbc.queryForObject(
					"select id, name from customer where name = ?",
					customerRowMapper, customerName);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<Customer> getCustomers() {
		return this.jdbc.<Customer> query("select id, name from customer",
				customerRowMapper);
	}

	// SingleColumnRowMapper updates the old ParameterizedRowMapper.
	private SingleColumnRowMapper<Customer> customerRowMapper = new SingleColumnRowMapper<Customer>() {
		public Customer mapRow(ResultSet rslt, int rowNum) throws SQLException {
			return new Customer(rslt.getString("id"), rslt.getString("name"));
		}
	};
}
