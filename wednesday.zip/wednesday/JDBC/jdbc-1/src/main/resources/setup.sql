create table customer (
  id varchar(36) not null,
  name varchar(32) not null,
  primary key (id),
  unique (name)
);

delete from customer;

insert into customer (id, name) values ('gc','Greg Curtis');
insert into customer (id, name) values ('jc','John Curtis');

commit;

