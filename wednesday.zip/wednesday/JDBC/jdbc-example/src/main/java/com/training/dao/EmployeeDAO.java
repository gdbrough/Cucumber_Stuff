package com.training.dao;

import java.util.List;

import com.training.model.Employee;

public interface EmployeeDAO {

	public void save(Employee employee);
	public Employee getEmployeeById(int id);
	public void updateEmployee(Employee employee);
	public void deleteEmployeeById(int id);
	public List<Employee> getAllEmployeesAsList();
}
