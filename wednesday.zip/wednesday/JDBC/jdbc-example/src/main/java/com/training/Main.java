package com.training;

import java.util.List;
import java.util.Random;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.dao.EmployeeDAO;
import com.training.model.Employee;

public class Main {

	public static void main(String[] args) {

		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
				"applicationContext.xml")) {

			// Get the EmployeeDAO Bean
			EmployeeDAO employeeDAO = ctx.getBean("employeeDAO",
					EmployeeDAO.class);

			// Run some tests for JDBC CRUD operations
			Employee emp = new Employee();
			int rand = new Random().nextInt(1000);
			emp.setId(rand);
			emp.setName("Greg");
			emp.setRole("Consultant");

			// Create
			employeeDAO.save(emp);

			// Read
			Employee emp1 = employeeDAO.getEmployeeById(rand);
			System.out.println("Employee Retrieved::" + emp1);

			// Update
			emp.setRole("CEO");
			employeeDAO.updateEmployee(emp);

			// Get All
			List<Employee> empList = employeeDAO.getAllEmployeesAsList();
			System.out.println(empList);

			// Delete
			//employeeDAO.deleteEmployeeById(rand);

		}
	}
}