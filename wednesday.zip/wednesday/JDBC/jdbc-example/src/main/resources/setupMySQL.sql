CREATE TABLE Employee (
  id int(11) unsigned NOT NULL,
  name varchar(20) DEFAULT NULL,
  jobrole varchar(20) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--delete from Employee;

--insert into Employee (id, name) values ('jjoe','Java Joe');
--insert into Employee (id, name) values ('jjohn','Java John');

--commit;

