create table Employee (
  id number(11) not null,
  name varchar2(20) default null,
  role varchar2(20) default null,
  primary key (id));
  
  
--delete from customer;
--
--insert into customer (id, name) values ('jjoe','Java Joe');
--insert into customer (id, name) values ('jjohn','Java John');
--
--commit;

