package com.training;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
 
@Configuration
@ComponentScan(basePackages = "com.training")
@EnableAspectJAutoProxy
public class AppConfig {
 
    // Aspect must also be a Bean
    @Bean 
    public EmployeeAspect employeeAspect() {
        return new EmployeeAspect();
    }
}