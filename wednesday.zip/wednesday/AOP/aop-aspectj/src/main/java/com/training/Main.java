package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml")) {
			EmployeeManager manager = context.getBean(EmployeeManager.class);
			manager.getEmployeeById(1);
			//manager.createEmployee(new Employee());
		}
	}
}