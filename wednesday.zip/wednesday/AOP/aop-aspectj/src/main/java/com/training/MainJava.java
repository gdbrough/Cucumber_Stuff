package com.training;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainJava {

	public static void main(String[] args) {
		try(AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class)) {
			EmployeeManager manager = context.getBean(EmployeeManager.class);
			manager.getEmployeeById(1);
			//manager.createEmployee(new Employee());
		}
	}
}