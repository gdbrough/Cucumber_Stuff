package com.training;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@SuppressWarnings("unused")
@Component
public class EmployeeManager {
	
	public Employee getEmployeeById(Integer employeeId) {
		System.out.println("getEmployeeById().");
		return new Employee();
	}

	/*
	public List<Employee> getAllEmployee() {
		System.out.println("getAllEmployee().");
		return new ArrayList<Employee>();
	}

	public void createEmployee(Employee employee) {
		System.out.println("createEmployee().");
	}

	public void deleteEmployee(Integer employeeId) {
		System.out.println("deleteEmployee().");
	}

	public void updateEmployee(Employee employee) {
		System.out.println("updateEmployee().");
	}
	*/
}