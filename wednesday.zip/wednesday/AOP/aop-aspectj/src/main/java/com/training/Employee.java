package com.training;

public class Employee {

	private Integer id;
	private String firstName;
	private String lastName;

	public String getFirstName() {
		return firstName;
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
