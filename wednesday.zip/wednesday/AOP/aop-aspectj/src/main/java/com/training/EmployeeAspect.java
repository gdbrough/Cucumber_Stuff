package com.training;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@SuppressWarnings("unused")
@Aspect
public class EmployeeAspect {

	@Before("execution(* EmployeeManager.getEmployeeById(..))")
	public void beforeGetById(JoinPoint joinPoint) {
		System.out.println("beforeGetById(): " + joinPoint.getSignature().getName());
	}

	/*
	@Before("execution(* EmployeeManager.*(..))")
	public void beforeAll(JoinPoint joinPoint) {
		System.out.println("beforeAll(): " + joinPoint.getSignature().getName());
	}

	@After("execution(* EmployeeManager.getEmployeeById(..))")
	public void afterGetById(JoinPoint joinPoint) {
		System.out.println("afterGetById(): " + joinPoint.getSignature().getName());
	}

	@After("execution(* EmployeeManager.*(..))")
	public void afterAll(JoinPoint joinPoint) {
		System.out.println("afterAll(): " + joinPoint.getSignature().getName());
	}
	*/
}