package com.training;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) throws Exception {

		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml")) {

			Customer customer = (Customer) context.getBean("customer");

			// customer.addCustomer();
			// customer.addCustomerReturnValue();
			// customer.addCustomerThrowException();
			customer.addCustomerAround("Curtis");
		}
	}
}