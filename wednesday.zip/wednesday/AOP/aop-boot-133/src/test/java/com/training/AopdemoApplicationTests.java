package com.training;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;

//import org.springframework.boot.test.rule.OutputCapture;
import org.springframework.boot.test.OutputCapture;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = AopdemoApplication.class)
public class AopdemoApplicationTests {

	@Test
	public void contextLoads() {
	}

	@Rule
	public OutputCapture outputCapture = new OutputCapture();

	private String profiles;

	@Before
	public void init() {
		this.profiles = System.getProperty("spring.profiles.active");
	}

	@After
	public void after() {
		if (this.profiles != null) {
			System.setProperty("spring.profiles.active", this.profiles);
		}
		else {
			System.clearProperty("spring.profiles.active");
		}
	}

	@Test
	public void testDefaultSettings() throws Exception {
		AopdemoApplication.main(new String[0]);
		String output = this.outputCapture.toString();
		assertThat(output).contains("Hello Greg");
	}

	@Test
	public void testCommandLineOverrides() throws Exception {
		AopdemoApplication.main(new String[] { "--name=Larry" });
		String output = this.outputCapture.toString();
		assertThat(output).contains("Hello Larry");
	}
	
}
