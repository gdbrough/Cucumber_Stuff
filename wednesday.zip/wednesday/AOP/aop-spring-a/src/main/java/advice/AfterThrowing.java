package advice;

import org.springframework.aop.ThrowsAdvice;

public class AfterThrowing implements ThrowsAdvice {
	
	public void afterThrowing(IllegalArgumentException e) throws Throwable {
		System.out.println("AfterThrowing: fires after throwing exception.");
	}
}