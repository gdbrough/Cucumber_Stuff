package pointcut;

import java.util.Arrays;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class Around implements MethodInterceptor {
	
	@Override
	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		System.out.println("Around : method name : " + methodInvocation.getMethod().getName());
		System.out.println("Around : method arguments : " + Arrays.toString(methodInvocation.getArguments()));
 		System.out.println("Around : before method.");
		try {
			Object result = methodInvocation.proceed();
			System.out.println("Around : after method.");
			return result;
		} catch (IllegalArgumentException e) {
			System.out.println("Around : throw intercepted.");
			throw e;
		}
	}
}