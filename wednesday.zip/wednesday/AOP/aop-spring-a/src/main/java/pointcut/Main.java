package pointcut;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("/pointcut/applicationContext3.xml")){
			
		// With #1: wires around advice directly to bean
		// With #2: pointcut applies advice according to mappedName="printName" property (misspell and try again)
		// With #3: regex advisor maps according to method signature, ignoring customerPointcut
		
		CustomerService cust = (CustomerService) context.getBean("customerServiceProxy");
 
		cust.printName();
		cust.printURL();
//		try {
//			cust.printThrowException();
//		} catch (Exception e) {
//		}
		}
	}
	
}
