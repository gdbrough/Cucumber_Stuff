package com.training.model;

import org.springframework.stereotype.Component;

import com.training.aspect.Loggable;

@Component
public class Employee {

	private String name;
	
	public Employee() {
		this.setName("Greg");
	}

	public String getName() {
		return name;
	}

	@Loggable
	public void setName(String name) {
		this.name = name;
	}

	public void throwException() {
		throw new RuntimeException("Test Exception");
	}
}