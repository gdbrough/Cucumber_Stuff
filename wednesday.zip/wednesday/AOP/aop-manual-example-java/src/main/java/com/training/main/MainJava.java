package com.training.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.training.service.EmployeeService;

public class MainJava {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(AppConfig.class);

		EmployeeService employeeService = 
				context.getBean("employeeService", EmployeeService.class);
		System.out.println(employeeService.getEmployee().getName());
		employeeService.getEmployee().setName("Curtis");
		//employeeService.getEmployee().throwException();
		context.close();
	}

}
