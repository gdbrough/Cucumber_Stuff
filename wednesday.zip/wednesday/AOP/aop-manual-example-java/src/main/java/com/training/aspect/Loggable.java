package com.training.aspect;

public @interface Loggable {

}
