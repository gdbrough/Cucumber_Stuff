package com.training.model;

import com.training.aspect.Loggable;

public class Employee {

	private String name;
	
	public Employee() {
		this.setName("Greg");
	}

	public String getName() {
		return name;
	}

	@Loggable
	public void setName(String name) {
		this.name = name;
	}

	public void throwException() {
		throw new RuntimeException("Test Exception");
	}
}