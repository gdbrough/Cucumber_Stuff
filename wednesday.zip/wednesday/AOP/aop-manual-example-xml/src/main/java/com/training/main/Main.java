package com.training.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.service.EmployeeService;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		EmployeeService employeeService = 
				context.getBean("employeeService", EmployeeService.class);
		System.out.println(employeeService.getEmployee().getName());
		employeeService.getEmployee().setName("Curtis");
		employeeService.getEmployee().throwException();
		context.close();
	}
}