package core;

import java.util.Arrays;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Before;

/**
 * Similar to a full logging method interceptor, this implementation produces a
 * simplified debugging log message.
 */
public class SummarizingMethodAdvice implements MethodInterceptor {
	@Before("execution(* *(..))")
	public Object invoke(MethodInvocation inv) throws Throwable {
		String buffer = "[" + inv.getThis().getClass().getSimpleName() + "]"
				+ " " + inv.getMethod().toString() + ". args="
				+ Arrays.toString(inv.getArguments());
		try {
			Object returnValue = inv.proceed();
			buffer += ". exit=return[" + returnValue + "]";
			return returnValue;
		} catch (Throwable t) {
			buffer += "  - exit=error[" + t + "]";
			throw t;
		} finally {
			Logger log = Logger.getLogger(inv.getThis().getClass());
			log.debug(">>> " + buffer);
		}
	}
}
