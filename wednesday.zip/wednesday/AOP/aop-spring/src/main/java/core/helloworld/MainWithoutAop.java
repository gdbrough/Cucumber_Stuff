package core.helloworld;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import core.Customer;
import core.CustomerQuery;

public class MainWithoutAop {

	public static void main(String[] args) throws Exception {

		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "/core/coreContext.xml" })) {

			CustomerQuery query = (CustomerQuery) context.getBean("customerQuery");

			Customer customer = query.getCustomerByName("Java Joe");

			System.out.println(customer);
		}

	}
}
