package core.pointcut.within;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import core.CustomerQuery;

public class Main {

	public static void main(String[] args) throws Exception {

		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "/core/pointcut/within/coreAopContext.xml", "/core/coreContext.xml" })) {

			CustomerQuery query = (CustomerQuery) context.getBean("customerQuery");

			query.getCustomerByName("Java Joe");

		}
	}

}
