package core.pointcut.execution;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import core.CustomerQuery;

public class Main {

	public static void main(String[] args) throws Exception {

		try (ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
				new String[] { "/core/pointcut/execution/coreAopContext.xml", "/core/coreContext.xml" })) {

			CustomerQuery query = (CustomerQuery) context.getBean("customerQuery");

			query.getCustomerByName("Java John");
		}
	}
}