package core;

public interface CustomerReport {

	public String getReport(String customerName);

}
