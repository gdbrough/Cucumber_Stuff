package com.training.shapes;

public interface Shape {
	public double getArea();
}
