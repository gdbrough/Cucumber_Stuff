package java_config;

public interface HelloWorld {
	 
	void printHelloWorld(String msg);
 
}