package xml_config;

public class Hello {

	private String name;
	
	public Hello() {
		// TODO Auto-generated constructor stub
	}
	
	public Hello(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
