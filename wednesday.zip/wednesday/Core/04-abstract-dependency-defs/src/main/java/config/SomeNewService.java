package config;

public interface SomeNewService {

}