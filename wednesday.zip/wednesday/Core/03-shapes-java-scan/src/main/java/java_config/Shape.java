package java_config;

public interface Shape {
	
	double getArea();

}
