package java_config;

public interface Hello {
	 
	String getName();
 
}