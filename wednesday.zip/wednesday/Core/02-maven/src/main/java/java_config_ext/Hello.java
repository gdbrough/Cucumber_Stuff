package java_config_ext;

public interface Hello {
	 
	String getName();
 
}