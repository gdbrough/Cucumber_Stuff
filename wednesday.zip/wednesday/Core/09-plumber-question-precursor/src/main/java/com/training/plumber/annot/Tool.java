package com.training.plumber.annot;

public interface Tool {

	void setSize(int size);
	int getSize();
}
