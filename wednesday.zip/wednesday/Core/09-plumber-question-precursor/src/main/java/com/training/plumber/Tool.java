package com.training.plumber;

public interface Tool {

	void setSize(int size);
	int getSize();
}
