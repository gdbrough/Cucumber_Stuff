package config;

public interface DatabaseService {

	String getDbInfo();
}
