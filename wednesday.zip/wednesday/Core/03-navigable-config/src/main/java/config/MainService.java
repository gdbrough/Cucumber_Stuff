package config;

public interface MainService {

	public String getDetails();
}
