package com.training;

public interface Tool {

	void setSize(int size);
	int getSize();
}
