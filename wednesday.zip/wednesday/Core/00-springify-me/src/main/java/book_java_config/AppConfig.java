package book_java_config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
 
@Configuration
@ComponentScan(basePackages = "book_java_config")
public class AppConfig {
 
    @Bean(name="libraryBean")
    public Library library() {
    	return new Library(bookList());
    }
    
    @Bean(name="bookListBean")
    public List<Book> bookList() {
		List<Book> bookList = new ArrayList<Book>();
		bookList.add(new Book("Time of Contempt", "A.Sapkowski"));
		bookList.add(new Book("The Drowned World", "J.G.Ballard"));
		bookList.add(new Book("The Stars My Destination", "A.Bester"));
    	return bookList;
    }
}