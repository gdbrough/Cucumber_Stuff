package book_java_config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {

		try (AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(AppConfig.class)) {
			
			Library library = (Library) context.getBean("libraryBean");
			System.out.println(library);
			System.out.println("No. of books: " + library.getBookList().size());
		}
	}
}