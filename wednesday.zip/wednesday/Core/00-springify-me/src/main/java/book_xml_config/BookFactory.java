package book_xml_config;

import org.springframework.beans.factory.config.AbstractFactoryBean;

public class BookFactory extends AbstractFactoryBean<Object> {
	private String title;
	private String author;
	
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	// This method will be called by container to create new instances
	@Override
	protected Object createInstance() throws Exception {
		Book book = new Book("dummy", "dummy");
		book.setTitle(title);
		book.setAuthor(author);
		return book;
	}

	// This method is required for autowiring to work correctly
	@Override
	public Class<Book> getObjectType() {
		return Book.class;
	}
}