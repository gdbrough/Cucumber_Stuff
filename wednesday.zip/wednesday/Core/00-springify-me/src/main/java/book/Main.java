package book;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		List<Book> bookList = new ArrayList<Book>();
		bookList.add(new Book("Time of Contempt", "A.Sapkowski"));
		bookList.add(new Book("The Drowned World", "J.G.Ballard"));
		bookList.add(new Book("The Stars My Destination", "A.Bester"));
				
		Library library = new Library(bookList);
		System.out.println(library);
		System.out.println("No of books: " + library.getBookList().size());
	}
}
