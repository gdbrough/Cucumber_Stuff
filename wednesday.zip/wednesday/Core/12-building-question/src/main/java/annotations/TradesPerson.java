package annotations;

public interface TradesPerson {
	public double getCost();
	public double getDays();
	public double getNumber();

	
}
